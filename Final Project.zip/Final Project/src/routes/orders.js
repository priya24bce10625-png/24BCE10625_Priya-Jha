const express = require("express");
const { ObjectId } = require("mongodb");
const { getDB } = require("../config/db");

const router = express.Router();

router.post("/", async (req, res) => {
  try {
    const db = getDB();
    // Validate customer exists
    const customer = await db.collection("customers").findOne({ _id: new ObjectId(req.body.customer_id) });
    if (!customer) return res.status(404).json({ message: "Customer not found" });
    // Validate restaurant exists
    const restaurant = await db.collection("restaurants").findOne({ _id: new ObjectId(req.body.restaurant_id) });
    if (!restaurant) return res.status(404).json({ message: "Restaurant not found" });

    const order = {
      customer_id: req.body.customer_id,
      restaurant_id: req.body.restaurant_id,
      items: req.body.items || [],
      status: "pending",
      total_price: req.body.total_price || 0,
      created_at: new Date(),
    };
    const result = await db.collection("orders").insertOne(order);
    res.status(201).json({ message: "Order placed ✅", id: result.insertedId });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

router.get("/", async (req, res) => {
  try {
    const db = getDB();
    const orders = await db.collection("orders").find().toArray();
    res.json(orders);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

router.get("/:id", async (req, res) => {
  try {
    const db = getDB();
    const order = await db.collection("orders").findOne({ _id: new ObjectId(req.params.id) });
    if (!order) return res.status(404).json({ message: "Order not found" });
    res.json(order);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

router.put("/:id", async (req, res) => {
  try {
    const db = getDB();
    const validStatuses = ["pending", "preparing", "out-for-delivery", "delivered"];
    if (!validStatuses.includes(req.body.status)) {
      return res.status(400).json({ message: "Invalid status" });
    }
    const result = await db.collection("orders").updateOne(
      { _id: new ObjectId(req.params.id) },
      { $set: { status: req.body.status } }
    );
    if (result.matchedCount === 0) return res.status(404).json({ message: "Order not found" });
    res.json({ message: "Order status updated ✅", modifiedCount: result.modifiedCount });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

router.delete("/:id", async (req, res) => {
  try {
    const db = getDB();
    const result = await db.collection("orders").deleteOne({ _id: new ObjectId(req.params.id) });
    if (result.deletedCount === 0) return res.status(404).json({ message: "Order not found" });
    res.status(204).send();
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

module.exports = router;