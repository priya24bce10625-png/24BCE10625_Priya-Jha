const express = require("express");
const { getDB } = require("../config/db");

const router = express.Router();

router.get("/", async (req, res) => {
  try {
    const db = getDB();
    const totalStaff = await db.collection("staff").countDocuments();
    const totalCustomers = await db.collection("customers").countDocuments();
    const totalRestaurants = await db.collection("restaurants").countDocuments();
    const totalMenuItems = await db.collection("menuItems").countDocuments();
    const totalOrders = await db.collection("orders").countDocuments();
    const totalDepartments = await db.collection("departments").countDocuments();

    const revenueResult = await db.collection("orders").aggregate([
      { $group: { _id: null, total: { $sum: "$total_price" } } }
    ]).toArray();
    const totalRevenue = revenueResult.length > 0 ? revenueResult[0].total : 0;

    const statusBreakdown = await db.collection("orders").aggregate([
      { $group: { _id: "$status", count: { $sum: 1 } } }
    ]).toArray();
    const orderStatus = {};
    statusBreakdown.forEach(item => { orderStatus[item._id] = item.count; });

    res.json({
      total_staff: totalStaff,
      total_customers: totalCustomers,
      total_restaurants: totalRestaurants,
      total_menu_items: totalMenuItems,
      total_orders: totalOrders,
      total_departments: totalDepartments,
      total_revenue: totalRevenue,
      order_status_breakdown: orderStatus,
      generated_at: new Date()
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

module.exports = router;