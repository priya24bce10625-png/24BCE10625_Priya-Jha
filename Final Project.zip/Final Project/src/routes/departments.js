const express = require("express");
const { ObjectId } = require("mongodb");
const { getDB } = require("../config/db");

const router = express.Router();

router.post("/", async (req, res) => {
  try {
    const db = getDB();
    const department = {
      name: req.body.name,
      head: req.body.head,
      staff_ids: req.body.staff_ids || [],
      created_at: new Date(),
    };
    const result = await db.collection("departments").insertOne(department);
    res.status(201).json({ message: "Department added ✅", id: result.insertedId });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

router.get("/", async (req, res) => {
  try {
    const db = getDB();
    const list = await db.collection("departments").find().toArray();
    res.json(list);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

router.get("/:id", async (req, res) => {
  try {
    const db = getDB();
    const department = await db.collection("departments").findOne({ _id: new ObjectId(req.params.id) });
    if (!department) return res.status(404).json({ message: "Department not found" });
    res.json(department);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

router.put("/:id", async (req, res) => {
  try {
    const db = getDB();
    // Validate staff exists
    const staff = await db.collection("staff").findOne({ _id: new ObjectId(req.body.staff_id) });
    if (!staff) return res.status(404).json({ message: "Staff not found" });

    const result = await db.collection("departments").updateOne(
      { _id: new ObjectId(req.params.id) },
      { $push: { staff_ids: req.body.staff_id } }
    );
    if (result.matchedCount === 0) return res.status(404).json({ message: "Department not found" });
    res.json({ message: "Staff assigned to department ✅", modifiedCount: result.modifiedCount });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

router.delete("/:id", async (req, res) => {
  try {
    const db = getDB();
    const result = await db.collection("departments").deleteOne({ _id: new ObjectId(req.params.id) });
    if (result.deletedCount === 0) return res.status(404).json({ message: "Department not found" });
    res.status(204).send();
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

module.exports = router;