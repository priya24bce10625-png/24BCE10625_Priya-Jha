const express = require("express");
const { ObjectId } = require("mongodb");
const { getDB } = require("../config/db");

const router = express.Router();

router.post("/", async (req, res) => {
  try {
    const db = getDB();
    const menuItem = {
      name: req.body.name,
      price: req.body.price,
      category: req.body.category,
      restaurant: req.body.restaurant,
      available: req.body.available !== undefined ? req.body.available : true,
      created_at: new Date(),
    };
    const result = await db.collection("menuItems").insertOne(menuItem);
    res.status(201).json({ message: "Menu item added ✅", id: result.insertedId });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

router.get("/", async (req, res) => {
  try {
    const db = getDB();
    const list = await db.collection("menuItems").find().toArray();
    res.json(list);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

router.get("/:id", async (req, res) => {
  try {
    const db = getDB();
    const item = await db.collection("menuItems").findOne({ _id: new ObjectId(req.params.id) });
    if (!item) return res.status(404).json({ message: "Menu item not found" });
    res.json(item);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

router.put("/:id", async (req, res) => {
  try {
    const db = getDB();
    const result = await db.collection("menuItems").updateOne(
      { _id: new ObjectId(req.params.id) },
      { $set: { available: req.body.available } }
    );
    if (result.matchedCount === 0) return res.status(404).json({ message: "Menu item not found" });
    res.json({ message: "Menu item updated ✅", modifiedCount: result.modifiedCount });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

router.delete("/:id", async (req, res) => {
  try {
    const db = getDB();
    const result = await db.collection("menuItems").deleteOne({ _id: new ObjectId(req.params.id) });
    if (result.deletedCount === 0) return res.status(404).json({ message: "Menu item not found" });
    res.status(204).send();
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

module.exports = router;