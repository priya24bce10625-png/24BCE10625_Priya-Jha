const express = require("express");
const { ObjectId } = require("mongodb");
const { getDB } = require("../config/db");

const router = express.Router();

router.post("/", async (req, res) => {
  try {
    const db = getDB();
    const restaurant = {
      name: req.body.name,
      address: req.body.address,
      cuisines: req.body.cuisines || [],
      open_hours: req.body.open_hours,
      rating: req.body.rating || 0,
      created_at: new Date(),
    };
    const result = await db.collection("restaurants").insertOne(restaurant);
    res.status(201).json({ message: "Restaurant added ✅", id: result.insertedId });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

router.get("/", async (req, res) => {
  try {
    const db = getDB();
    const list = await db.collection("restaurants").find().toArray();
    res.json(list);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

router.get("/:id", async (req, res) => {
  try {
    const db = getDB();
    const restaurant = await db.collection("restaurants").findOne({ _id: new ObjectId(req.params.id) });
    if (!restaurant) return res.status(404).json({ message: "Restaurant not found" });
    res.json(restaurant);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

router.put("/:id", async (req, res) => {
  try {
    const db = getDB();
    const result = await db.collection("restaurants").updateOne(
      { _id: new ObjectId(req.params.id) },
      { $set: { rating: req.body.rating } }
    );
    if (result.matchedCount === 0) return res.status(404).json({ message: "Restaurant not found" });
    res.json({ message: "Restaurant updated ✅", modifiedCount: result.modifiedCount });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

router.delete("/:id", async (req, res) => {
  try {
    const db = getDB();
    const result = await db.collection("restaurants").deleteOne({ _id: new ObjectId(req.params.id) });
    if (result.deletedCount === 0) return res.status(404).json({ message: "Restaurant not found" });
    res.status(204).send();
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

module.exports = router;