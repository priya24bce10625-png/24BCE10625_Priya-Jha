const express = require("express");
const { ObjectId } = require("mongodb");
const { getDB } = require("../config/db");

const router = express.Router();

// CREATE
router.post("/", async (req, res) => {
  try {
    const db = getDB();
    const staff = {
      name: req.body.name,
      role: req.body.role,
      phone: req.body.phone,
      department: req.body.department,
      status: "available",
      orders_assigned: 0,
      created_at: new Date(),
    };
    const result = await db.collection("staff").insertOne(staff);
    res.status(201).json({ message: "Staff added ✅", id: result.insertedId });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// READ ALL
router.get("/", async (req, res) => {
  try {
    const db = getDB();
    const list = await db.collection("staff").find().toArray();
    res.json(list);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// READ ONE
router.get("/:id", async (req, res) => {
  try {
    const db = getDB();
    const staff = await db.collection("staff").findOne({ _id: new ObjectId(req.params.id) });
    if (!staff) return res.status(404).json({ message: "Staff not found" });
    res.json(staff);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// UPDATE
router.put("/:id", async (req, res) => {
  try {
    const db = getDB();
    const result = await db.collection("staff").updateOne(
      { _id: new ObjectId(req.params.id) },
      { $set: { status: req.body.status } }
    );
    if (result.matchedCount === 0) {
      return res.status(404).json({ message: "Staff not found" });
    }
    res.json({ message: "Staff updated ✅", modifiedCount: result.modifiedCount });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// DELETE
router.delete("/:id", async (req, res) => {
  try {
    const db = getDB();
    const result = await db.collection("staff").deleteOne({ _id: new ObjectId(req.params.id) });
    if (result.deletedCount === 0) {
      return res.status(404).json({ message: "Staff not found" });
    }
    res.status(204).send();
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

module.exports = router;