const swaggerDocument = {
  openapi: "3.0.0",
  info: {
    title: "Food Delivery Management System API",
    version: "1.0.0",
    description: "Complete REST API for managing food delivery operations including restaurants, customers, orders, and delivery staff",
  },
  servers: [{ 
    url: "http://localhost:3000",
    description: "Development Server"
  }],
  
  components: {
    schemas: {
      Staff: {
        type: "object",
        properties: {
          name: { type: "string", example: "Amit Sharma" },
          role: { type: "string", enum: ["delivery_agent", "manager", "chef"], example: "delivery_agent" },
          phone: { type: "string", example: "9822002200" },
          department: { type: "string", example: "ops" },
          status: { type: "string", enum: ["available", "busy", "offline"], example: "available" }
        }
      },
      Customer: {
        type: "object",
        properties: {
          name: { type: "string", example: "Ananya Das" },
          phone: { type: "string", example: "9700001111" },
          email: { type: "string", example: "ananya@mail.com" },
          address: { type: "string", example: "Delhi" }
        }
      },
      Restaurant: {
        type: "object",
        properties: {
          name: { type: "string", example: "Spice Garden" },
          address: { type: "string", example: "Delhi" },
          cuisines: { type: "array", items: { type: "string" }, example: ["Indian", "Chinese"] },
          open_hours: { type: "string", example: "9AM-11PM" },
          rating: { type: "number", example: 4.5 }
        }
      },
      MenuItem: {
        type: "object",
        properties: {
          name: { type: "string", example: "Butter Chicken" },
          price: { type: "number", example: 280 },
          category: { type: "string", enum: ["veg", "non-veg"], example: "non-veg" },
          restaurant: { type: "string", example: "Spice Garden" },
          available: { type: "boolean", example: true }
        }
      },
      Order: {
        type: "object",
        properties: {
          customer_id: { type: "string", example: "65f8a1b2c3d4e5f6a7b8c9d0" },
          restaurant_id: { type: "string", example: "65f8a1b2c3d4e5f6a7b8c9d1" },
          items: { type: "array", items: { type: "string" }, example: ["Butter Chicken", "Naan"] },
          status: { type: "string", enum: ["pending", "preparing", "out-for-delivery", "delivered"], example: "pending" },
          total_price: { type: "number", example: 560 }
        }
      },
      Department: {
        type: "object",
        properties: {
          name: { type: "string", example: "Operations" },
          head: { type: "string", example: "Rajan Kumar" },
          staff_ids: { type: "array", items: { type: "string" }, example: ["65f8a1b2c3d4e5f6a7b8c9d2"] }
        }
      }
    }
  },

  paths: {
    // ============ STAFF ============
    "/staff": {
      post: { 
        summary: "Add new staff member",
        tags: ["Staff"],
        requestBody: { 
          required: true,
          content: { 
            "application/json": { 
              schema: { $ref: "#/components/schemas/Staff" }
            } 
          } 
        },
        responses: { 
          201: { description: "Staff added successfully" },
          400: { description: "Validation error" }
        } 
      },
      get: { 
        summary: "Get all staff members",
        tags: ["Staff"],
        responses: { 
          200: { 
            description: "List of all staff",
            content: {
              "application/json": {
                schema: {
                  type: "array",
                  items: { $ref: "#/components/schemas/Staff" }
                }
              }
            }
          } 
        } 
      },
    },
    "/staff/{id}": {
      get: { 
        summary: "Get staff by ID",
        tags: ["Staff"],
        parameters: [{ 
          name: "id", 
          in: "path", 
          required: true, 
          schema: { type: "string" },
          description: "Staff MongoDB ObjectId"
        }],
        responses: { 
          200: { description: "Staff found" },
          404: { description: "Staff not found" }
        } 
      },
      put: { 
        summary: "Update staff details",
        tags: ["Staff"],
        parameters: [{ 
          name: "id", 
          in: "path", 
          required: true, 
          schema: { type: "string" }
        }],
        requestBody: { 
          content: { 
            "application/json": { 
              schema: { 
                type: "object",
                properties: {
                  status: { type: "string", enum: ["available", "busy", "offline"] }
                }
              }
            } 
          } 
        },
        responses: { 
          200: { description: "Staff updated" },
          404: { description: "Staff not found" }
        } 
      },
      delete: { 
        summary: "Delete staff member",
        tags: ["Staff"],
        parameters: [{ 
          name: "id", 
          in: "path", 
          required: true, 
          schema: { type: "string" }
        }],
        responses: { 
          204: { description: "Staff deleted" },
          404: { description: "Staff not found" }
        } 
      },
    },

    // ============ CUSTOMERS ============
    "/customers": {
      post: { 
        summary: "Add new customer",
        tags: ["Customers"],
        requestBody: { 
          required: true,
          content: { 
            "application/json": { 
              schema: { $ref: "#/components/schemas/Customer" }
            } 
          } 
        },
        responses: { 
          201: { description: "Customer added" },
          400: { description: "Validation error" }
        } 
      },
      get: { 
        summary: "Get all customers",
        tags: ["Customers"],
        responses: { 
          200: { 
            description: "List of customers",
            content: {
              "application/json": {
                schema: {
                  type: "array",
                  items: { $ref: "#/components/schemas/Customer" }
                }
              }
            }
          } 
        } 
      },
    },
    "/customers/{id}": {
      get: { 
        summary: "Get customer by ID",
        tags: ["Customers"],
        parameters: [{ 
          name: "id", 
          in: "path", 
          required: true, 
          schema: { type: "string" }
        }],
        responses: { 
          200: { description: "Customer found" },
          404: { description: "Customer not found" }
        } 
      },
      put: { 
        summary: "Update customer details",
        tags: ["Customers"],
        parameters: [{ 
          name: "id", 
          in: "path", 
          required: true, 
          schema: { type: "string" }
        }],
        requestBody: { 
          content: { 
            "application/json": { 
              schema: { 
                type: "object",
                properties: {
                  address: { type: "string", example: "Mumbai" },
                  phone: { type: "string", example: "9876543210" }
                }
              }
            } 
          } 
        },
        responses: { 
          200: { description: "Customer updated" },
          404: { description: "Customer not found" }
        } 
      },
      delete: { 
        summary: "Delete customer",
        tags: ["Customers"],
        parameters: [{ 
          name: "id", 
          in: "path", 
          required: true, 
          schema: { type: "string" }
        }],
        responses: { 
          204: { description: "Customer deleted" },
          404: { description: "Customer not found" }
        } 
      },
    },

    // ============ RESTAURANTS ============
    "/restaurants": {
      post: { 
        summary: "Add new restaurant",
        tags: ["Restaurants"],
        requestBody: { 
          required: true,
          content: { 
            "application/json": { 
              schema: { $ref: "#/components/schemas/Restaurant" }
            } 
          } 
        },
        responses: { 
          201: { description: "Restaurant added" },
          400: { description: "Validation error" }
        } 
      },
      get: { 
        summary: "Get all restaurants",
        tags: ["Restaurants"],
        responses: { 
          200: { 
            description: "List of restaurants",
            content: {
              "application/json": {
                schema: {
                  type: "array",
                  items: { $ref: "#/components/schemas/Restaurant" }
                }
              }
            }
          } 
        } 
      },
    },
    "/restaurants/{id}": {
      get: { 
        summary: "Get restaurant by ID",
        tags: ["Restaurants"],
        parameters: [{ 
          name: "id", 
          in: "path", 
          required: true, 
          schema: { type: "string" }
        }],
        responses: { 
          200: { description: "Restaurant found" },
          404: { description: "Restaurant not found" }
        } 
      },
      put: { 
        summary: "Update restaurant rating",
        tags: ["Restaurants"],
        parameters: [{ 
          name: "id", 
          in: "path", 
          required: true, 
          schema: { type: "string" }
        }],
        requestBody: { 
          content: { 
            "application/json": { 
              schema: { 
                type: "object",
                properties: {
                  rating: { type: "number", minimum: 0, maximum: 5, example: 4.5 }
                }
              }
            } 
          } 
        },
        responses: { 
          200: { description: "Restaurant updated" },
          404: { description: "Restaurant not found" }
        } 
      },
      delete: { 
        summary: "Delete restaurant",
        tags: ["Restaurants"],
        parameters: [{ 
          name: "id", 
          in: "path", 
          required: true, 
          schema: { type: "string" }
        }],
        responses: { 
          204: { description: "Restaurant deleted" },
          404: { description: "Restaurant not found" }
        } 
      },
    },

    // ============ MENU ============
    "/menu": {
      post: { 
        summary: "Add new menu item",
        tags: ["Menu"],
        requestBody: { 
          required: true,
          content: { 
            "application/json": { 
              schema: { $ref: "#/components/schemas/MenuItem" }
            } 
          } 
        },
        responses: { 
          201: { description: "Menu item added" },
          400: { description: "Validation error" }
        } 
      },
      get: { 
        summary: "Get all menu items",
        tags: ["Menu"],
        responses: { 
          200: { 
            description: "List of menu items",
            content: {
              "application/json": {
                schema: {
                  type: "array",
                  items: { $ref: "#/components/schemas/MenuItem" }
                }
              }
            }
          } 
        } 
      },
    },
    "/menu/{id}": {
      get: { 
        summary: "Get menu item by ID",
        tags: ["Menu"],
        parameters: [{ 
          name: "id", 
          in: "path", 
          required: true, 
          schema: { type: "string" }
        }],
        responses: { 
          200: { description: "Menu item found" },
          404: { description: "Menu item not found" }
        } 
      },
      put: { 
        summary: "Toggle menu item availability",
        tags: ["Menu"],
        parameters: [{ 
          name: "id", 
          in: "path", 
          required: true, 
          schema: { type: "string" }
        }],
        requestBody: { 
          content: { 
            "application/json": { 
              schema: { 
                type: "object",
                properties: {
                  available: { type: "boolean", example: false }
                }
              }
            } 
          } 
        },
        responses: { 
          200: { description: "Menu item updated" },
          404: { description: "Menu item not found" }
        } 
      },
      delete: { 
        summary: "Delete menu item",
        tags: ["Menu"],
        parameters: [{ 
          name: "id", 
          in: "path", 
          required: true, 
          schema: { type: "string" }
        }],
        responses: { 
          204: { description: "Menu item deleted" },
          404: { description: "Menu item not found" }
        } 
      },
    },

    // ============ ORDERS ============
    "/orders": {
      post: { 
        summary: "Place a new order",
        tags: ["Orders"],
        requestBody: { 
          required: true,
          content: { 
            "application/json": { 
              schema: { $ref: "#/components/schemas/Order" }
            } 
          } 
        },
        responses: { 
          201: { description: "Order placed successfully" },
          400: { description: "Validation error" }
        } 
      },
      get: { 
        summary: "Get all orders",
        tags: ["Orders"],
        responses: { 
          200: { 
            description: "List of orders",
            content: {
              "application/json": {
                schema: {
                  type: "array",
                  items: { $ref: "#/components/schemas/Order" }
                }
              }
            }
          } 
        } 
      },
    },
    "/orders/{id}": {
      get: { 
        summary: "Get order by ID",
        tags: ["Orders"],
        parameters: [{ 
          name: "id", 
          in: "path", 
          required: true, 
          schema: { type: "string" }
        }],
        responses: { 
          200: { description: "Order found" },
          404: { description: "Order not found" }
        } 
      },
      put: { 
        summary: "Update order status",
        tags: ["Orders"],
        parameters: [{ 
          name: "id", 
          in: "path", 
          required: true, 
          schema: { type: "string" }
        }],
        requestBody: { 
          content: { 
            "application/json": { 
              schema: { 
                type: "object",
                properties: {
                  status: { 
                    type: "string", 
                    enum: ["pending", "preparing", "out-for-delivery", "delivered"],
                    example: "delivered" 
                  }
                }
              }
            } 
          } 
        },
        responses: { 
          200: { description: "Order status updated" },
          404: { description: "Order not found" }
        } 
      },
      delete: { 
        summary: "Delete order",
        tags: ["Orders"],
        parameters: [{ 
          name: "id", 
          in: "path", 
          required: true, 
          schema: { type: "string" }
        }],
        responses: { 
          204: { description: "Order deleted" },
          404: { description: "Order not found" }
        } 
      },
    },

    // ============ DEPARTMENTS ============
    "/departments": {
      post: { 
        summary: "Add new department",
        tags: ["Departments"],
        requestBody: { 
          required: true,
          content: { 
            "application/json": { 
              schema: { $ref: "#/components/schemas/Department" }
            } 
          } 
        },
        responses: { 
          201: { description: "Department added" },
          400: { description: "Validation error" }
        } 
      },
      get: { 
        summary: "Get all departments",
        tags: ["Departments"],
        responses: { 
          200: { 
            description: "List of departments",
            content: {
              "application/json": {
                schema: {
                  type: "array",
                  items: { $ref: "#/components/schemas/Department" }
                }
              }
            }
          } 
        } 
      },
    },
    "/departments/{id}": {
      get: { 
        summary: "Get department by ID",
        tags: ["Departments"],
        parameters: [{ 
          name: "id", 
          in: "path", 
          required: true, 
          schema: { type: "string" }
        }],
        responses: { 
          200: { description: "Department found" },
          404: { description: "Department not found" }
        } 
      },
      put: { 
        summary: "Assign staff to department",
        tags: ["Departments"],
        parameters: [{ 
          name: "id", 
          in: "path", 
          required: true, 
          schema: { type: "string" }
        }],
        requestBody: { 
          content: { 
            "application/json": { 
              schema: { 
                type: "object",
                properties: {
                  staff_id: { type: "string", example: "65f8a1b2c3d4e5f6a7b8c9d2" }
                }
              }
            } 
          } 
        },
        responses: { 
          200: { description: "Staff assigned to department" },
          404: { description: "Department not found" }
        } 
      },
      delete: { 
        summary: "Delete department",
        tags: ["Departments"],
        parameters: [{ 
          name: "id", 
          in: "path", 
          required: true, 
          schema: { type: "string" }
        }],
        responses: { 
          204: { description: "Department deleted" },
          404: { description: "Department not found" }
        } 
      },
    },

    // ============ ANALYTICS ============
    "/analytics": {
      get: { 
        summary: "Get system analytics",
        tags: ["Analytics"],
        responses: { 
          200: { 
            description: "Analytics data",
            content: {
              "application/json": {
                schema: {
                  type: "object",
                  properties: {
                    total_orders: { type: "number", example: 150 },
                    total_customers: { type: "number", example: 75 },
                    total_restaurants: { type: "number", example: 12 },
                    total_staff: { type: "number", example: 30 },
                    revenue: { type: "number", example: 45000.50 }
                  }
                }
              }
            }
          } 
        } 
      },
    },
  },
};

module.exports = swaggerDocument;