const { MongoClient } = require("mongodb");
require('dotenv').config();

const URI = process.env.MONGODB_URI || "mongodb://localhost:27017";
const DB_NAME = process.env.DB_NAME || "food_delivery_db";

let db = null;

async function connectDB() {
  try {
    const client = new MongoClient(URI);
    await client.connect();
    db = client.db(DB_NAME);
    console.log("✅ MongoDB Connected:", DB_NAME);
    return db;
  } catch (error) {
    console.error("❌ MongoDB connection error:", error.message);
    throw error;
  }
}

function getDB() {
  if (!db) {
    throw new Error("Database not initialized. Call connectDB() first.");
  }
  return db;
}

module.exports = { connectDB, getDB };