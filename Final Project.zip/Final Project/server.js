require('dotenv').config();
const express = require("express");
const swaggerUi = require("swagger-ui-express");
const { connectDB } = require("./src/config/db");
const swaggerDocument = require("./src/config/swagger");

const staffRoutes = require("./src/routes/staff");
const customerRoutes = require("./src/routes/customers");
const restaurantRoutes = require("./src/routes/restaurants");
const menuRoutes = require("./src/routes/menuItems");
const orderRoutes = require("./src/routes/orders");
const departmentRoutes = require("./src/routes/departments");
const analyticsRoutes = require("./src/routes/analytics");

const app = express();
app.use(express.json());

app.use("/api-docs", swaggerUi.serve, swaggerUi.setup(swaggerDocument));

app.use("/staff", staffRoutes);
app.use("/customers", customerRoutes);
app.use("/restaurants", restaurantRoutes);
app.use("/menu", menuRoutes);
app.use("/orders", orderRoutes);
app.use("/departments", departmentRoutes);
app.use("/analytics", analyticsRoutes);

app.get("/", (req, res) => {
  res.send("Food Delivery Management System API is running. Visit /api-docs for Swagger documentation.");
});

const PORT = process.env.PORT || 3000;

connectDB()
  .then(() => {
    app.listen(PORT, () => {
      console.log(`🚀 Server running on http://localhost:${PORT}`);
      console.log(`📘 Swagger docs at http://localhost:${PORT}/api-docs`);
    });
  })
  .catch((err) => {
    console.error("❌ Failed to connect to MongoDB:", err.message);
    process.exit(1);
  });