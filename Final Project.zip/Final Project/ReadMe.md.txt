# Food Delivery Management System API

## Project Description
A backend REST API built with Node.js, Express.js, and MongoDB (native driver) to manage food delivery operations including Restaurants, Customers, Delivery Staff, Orders, Menu Items, Departments, and Analytics. The system exposes full CRUD APIs tested via Swagger UI.

## Technologies Used
- **Node.js** – JavaScript runtime
- **Express.js** – Web framework
- **MongoDB** – NoSQL database (Native Driver)
- **Swagger UI** – API documentation & testing
- **dotenv** – Environment variables

## Setup Instructions
1. Clone the repository or extract the project folder.
2. Run `npm install` to install dependencies.
3. Ensure MongoDB is running locally (or update `.env` with your MongoDB URI).
4. Create a `.env` file with:PORT=3000
MONGODB_URI=mongodb://localhost:27017
DB_NAME=food_delivery_db
5. Start the server: `node server.js` or `npm run dev`.
6. Open `http://localhost:3000/api-docs` to explore and test the APIs.

## API Endpoints
- **Staff**: POST, GET, GET/:id, PUT/:id, DELETE/:id
- **Customers**: POST, GET, GET/:id, PUT/:id, DELETE/:id
- **Restaurants**: POST, GET, GET/:id, PUT/:id, DELETE/:id
- **Menu Items**: POST, GET, GET/:id, PUT/:id, DELETE/:id
- **Orders**: POST, GET, GET/:id, PUT/:id, DELETE/:id
- **Departments**: POST, GET, GET/:id, PUT/:id, DELETE/:id
- **Analytics**: GET

## Testing
All APIs were manually tested using Swagger UI. Screenshots of the test results are provided in the `Documents` folder.

## Author
Priya Jha

## License
ISC